# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and Semantic Versioning.

## [Unreleased]

## [0.3.0] - 2026-07-23

### Changed

- Reset Waystone to a browser-only UI consumer of Workshop named operations.
- Bound public client/error types and all UI calls to the exact generated `@gnolith/workshop@0.5.0` schema-11, 52-operation catalog and verified `/app` asset contract.
- Replaced route, transport, authentication, server-error, and canonical DTO ownership with the structural `client.call(name, input, { signal })` boundary.
- Added complete accessible search, knowledge-content, Task lifecycle, readiness, SPARQL, and search-administration UI with explicit degraded and conflict states.
- Replaced executable plugins with validated static UI declarations.

### Added

- Added deterministic immutable CSS assets, a JCS-digested `waystone-assets-v1` manifest, CycloneDX SBOM, packed browser/declaration consumers, and candidate checksums.

### Removed

- Removed HTTP client construction, path maps, auth/token handling, protocol adapters, host operations, installation/onboarding, snapshot/restore, server, and deployment ownership.

## [0.2.1] - 2026-07-22

- Corrected the browser protocol boundary to exact public Taproot 0.4.0 and Workshop 0.4.1 artifacts: structured POST search, string source revisions, generic match/cursor preservation, typed references and hydration, canonical Resource/Annotation CRUD, complete Prompt CRUD/history metadata, and exact search-administration operations.
- Added lossless runtime adapter tests and packed bidirectional declaration conformance beyond Statement and EntityCommand.
- Removed the stale 0.3 compatibility claim; the optional Taproot peer floor is now 0.4.0 and the Workshop peer floor is 0.4.1.

## [0.2.0] - 2026-07-22

### Added

- Added the first-class, cursor-paginated seven-kind unified search client and accessible screen with explicit kind-aware filters, lexical/semantic readiness, degraded and cursor-recovery states, typed traceability, independent chunk rendering, and owning-route hydration.
- Added browser-safe Resource, Annotation, Prompt, Task, and Memory structural client contracts; Resource, Annotation, and Prompt display/edit/history components; selectors, linked identity, inherited visibility, and safe external-location handling.
- Added search health and exact-admin interfaces for estimates, explicit budget approval, configuration and schedule controls, bounded failures, circuits, retirement, and retained-embedding deletion, plus host-only snapshot/export/import/restore progress.
- Added deterministic transport, UI, redaction, authorization, accessibility, packed-consumer, and bundle-budget verification for the new surfaces.

### Changed

- Widened the optional structural Taproot peer range through 0.4. Waystone still imports no Taproot runtime; assembled Site compatibility remains a host acceptance responsibility.

### Changed

- Added mandatory authored text to Waystone and structural Taproot statement revisions. Adapters, HTTP serialization, fixtures, rendering, and mock persistence preserve the text exactly, while mutation editors require a new nonblank confirmation for add, replace, rank, qualifier, and reference changes instead of silently carrying earlier prose.

## [0.1.2] - 2026-07-21

### Fixed

- Added `@types/react` as a required React 19 peer so strict TypeScript consumers receive the declarations referenced by Waystone's public API.
- Replaced public Taproot declaration references with Waystone-owned structural protocol types. Strict `NodeNext` consumers no longer resolve Taproot's Diamond, Comunica, `rdf-parse`, or `lru-cache` declaration graph merely by importing Waystone.

### Changed

- Added exact packed TS and TSX consumer verification on TypeScript 5.9 with `strict: true` and `skipLibCheck: false`, including declaration-resolution and package-content boundary assertions.
- Removed the completed first-release bootstrap-token path. npm releases now use only the protected environment's OIDC trusted-publisher binding.

## [0.1.1] - 2026-07-21

### Changed

- Isolated package verification from sibling-repository source trees and legacy Workshop archives.
- Consolidated npm publication behind the protected GitHub Release publication event and added release-candidate guards.
- Adapted Workshop-shaped entity panels from Waystone's canonical `entity` prop to Workshop's `entityId` contract at the registry boundary.
- Clarified that headless and process-based consumers compose non-UI packages without importing Waystone.
- Added a temporary token-authenticated bootstrap path for the package's first npm publication while preserving provenance and OIDC; a fresh credential-only job has only ID-token permission and publishes a content-addressed archive after validating its paths, literal package identity, and release-tag-derived version without checking out repository code or enabling lifecycle scripts.
- Expanded Taproot compatibility through stable 0.2, moved isolated-consumer archives to unique temporary pack destinations, and separated the recursive consumer install from `prepack`.

### Known limitation

- The published declarations referenced React types without declaring `@types/react` as a peer and re-exported Taproot root types. A strict `NodeNext` consumer with `skipLibCheck: false` could therefore fail on missing React declarations or on Taproot's transitive Diamond/Comunica declaration graph. Version 0.1.2 corrects both package boundaries without changing runtime behavior.

### Added

- Production package implementation, explicit runtime entry points, declarations, and compiled CSS.
- Application shell, onboarding, knowledge browsing and maintenance, revision, and SPARQL surfaces.
- Browser-safe client with configurable paths, authentication callback, abort signals, typed errors, request IDs, and optimistic concurrency.
- Deterministic plugin registry and isolated extension rendering.
- Representative fixtures, mutable mock client, component/accessibility tests, package guards, bundle budgets, and an isolated vinext consumer fixture.

## [0.1.0] - 2026-07-20

### Added

- First production-candidate public contract.

[Unreleased]: https://github.com/gnolith/waystone/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/gnolith/waystone/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/gnolith/waystone/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/gnolith/waystone/compare/v0.1.2...v0.2.0
[0.1.2]: https://github.com/gnolith/waystone/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/gnolith/waystone/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/gnolith/waystone/releases/tag/v0.1.0
