# Changelog

## 0.5.0

- Identical Item and Property label updates are true semantic no-ops. Public
  mutation receipts and Workshop-facing write results expose an explicit
  `changed` disposition, while no-op writes retain authorization validation
  and an atomic current-state assertion without advancing canonical history,
  RDF, authorization, source-event, search, or materialization state.
- Fix exact Taproot 0.4.2 owner adoption to validate against an immutable,
  explicit migration ID/checksum manifest captured from the public 0.4.2
  package with Diamond 0.4.1. Legacy evidence is no longer derived from the
  current migration catalog.
- Keep current schema metadata and migration seeds authoritative during legacy
  conversion/import while preserving all legacy canonical entities, revision
  history, content records, and payload descriptors. Cross-process adoption
  compares only stable schema/migration identity while retaining the import
  target's installation metadata and non-semantic migration application
  timestamps. Fresh restore targets establish their registered canonical base
  IRI before importing domain state. Add a package-owned migration-ledger
  restore primitive that converges immutable sequential migration replay to
  the same exact physical catalog as fresh initialization. Legacy import
  rebuilds Taproot's RDF ownership and Diamond quad projection from canonical
  entities, and persistence inspection reports bounded readiness errors
  instead of swallowing semantic or seed failures.

- Add the sealed `AuthorizationAdministrationV1` owner protocol for
  revision-bound principal, workspace, grant, and canonical visibility
  administration. Workshop-owned credential/OAuth mappings join the same
  connection-local atomic batch; receipts are durable and idempotent, and
  authorization/search fences advance on every accepted mutation.
- Add declarative `SemanticConfigurationV1` identities for
  Ollama-compatible and OpenAI-compatible embedding providers plus SQLite and
  Qdrant vector stores. Configuration now persists selector identities (never
  credentials), explicit private-endpoint approval and redirect policy,
  revision/idempotency history, fingerprints, and safe vector generations.

- Registered external producers can read their exact frozen source-event
  predecessor through their capability-bound runtime after a commit or process
  restart; durable kind registrations can be rebound only by the matching
  deterministic owner registration.
- External producer projection text now accepts normalized multiline canonical
  content under the same nonblank UTF-8 byte bound as built-in projections.
- External producer adoption now persists source events and predecessors for
  enumerated legacy owner rows, including pages adopted after materialization
  initialization and later process restarts.
- Added the authority-bound `TaprootWorkshopPortV1` for live persisted
  principal/grant resolution and bounded, authorization-fenced statement,
  Resource, and Annotation revision history without exposing storage tables.
  Its idempotent operator mutations derive or preserve canonical entity and
  content policy inside Taproot, including all `EntityCommand` statement,
  qualifier, reference, and rank changes.
- Preserved ordered per-command authored text for atomic Workshop entity edits
  and added bounded, exact-revision Resource payload hydration.
- Made owner backup import independent of canonical JSON object-key order by
  validating the exact table manifest and restoring canonical and derived rows
  in declared foreign-key dependency order within one atomic batch.
- Made active materialization health converge after mixed built-in/external
  supersession by enrolling external-kind checkpoints and advancing only
  truthfully completed superseded jobs through their source sequence.

- Reset search to four built-in kinds (`item`, `statement`, `resource`, and
  `annotation`) plus privately branded, namespace-bound external kinds.
- Added canonical Resource/Annotation mutation boundaries, sealed
  authorization bootstrap, scoped SPARQL policy preparation, owner-scoped
  backup/blob ports, and read-only exact Taproot 0.4.2 adoption inspection.
- Moved search, semantic, vector/provider adapters, SPARQL policy, and backup
  into explicit package subpaths and removed raw SQL/foreign-domain bridges.
- Added restartable migration 0009 with lossless namespaced adoption of
  historical external search kinds.

## Unreleased

## 0.4.2

- Mirrored every authorized Statement text into its Item aggregate while
  preserving independent Statement documents, stable identities, bounded
  chunks, authorization partitions, and revision fencing.
- Serialized concurrent external Task, Memory, and Prompt commits across one
  installation with bounded generation-CAS retries and deterministic
  same-source conflict and domain-failure behavior.
- Made lexical health report `healthy` only at a caught-up steady state while
  retaining explicit `building`, `blocked`, and `degraded` states.
- Closed the public declaration surface over Taproot-owned structural SQLite/D1
  types and added a disposable strict TypeScript 5.9 consumer with
  `skipLibCheck: false`.

## 0.4.1

- Qualified and pinned the public `@gnolith/diamond@0.4.1` artifact across
  native SQLite, Workerd D1, migrations, prepared RDF patches, ledger,
  packed-consumer, and release gates. The disposable consumer now rejects any
  dependency graph other than one Diamond 0.4.1 runtime.
- Updated real-Qdrant conformance to the Seedbed-supported Linux/amd64
  `qdrant/qdrant:v1.18.2` manifest at digest
  `sha256:da65a06bc75e42702f80c992b99c5144b0fbd675ae7a96d2991de0bf957b7071`
  and added repository drift guards for both runtime coordinates.

## 0.4.0

- Added migration 0008 and the 0.4 public surface: canonical Resource and
  Web-Annotation-aligned records, injected portable payload hydration, native
  Resource/Annotation projection, authorized seven-kind lexical search,
  deterministic chunk results/cursors/hydration, configurable semantic fusion,
  durable embedding plans and budgets, SQLite and Qdrant vector adapters,
  OpenAI/Ollama-compatible embedding adapters, and installation snapshot/restore.
- Added shared native SQLite/Workerd content-search conformance, deterministic
  adapter tests, pinned real-Qdrant lifecycle CI, hybrid performance evidence,
  snapshot round trips, and a machine-checked 89-requirement evidence map.

- Added migration 0007 with immutable external-producer manifests, durable
  resumable adoption/audit state, generation-pinned fingerprints, distinct
  source-policy and live-authorization fences, and a host-sealed data-only
  Workshop Task/Memory boundary. Missing or mismatched process runtimes remain
  dynamically blocked without consuming attempts. Existing 0006 staged graphs
  are preserved on native SQLite and Workerd D1. Site deployment remains out of
  package scope.

- Added DDL-only migration 0006 and an opaque `search:admin`-guarded,
  runtime-neutral materialization lifecycle with bounded durable jobs,
  128-bit lease tokens and ABA fencing, invisible staged manifests, atomic
  replace-all heads/tombstones, immediate stale-head invalidation, deterministic
  retry/dead handling, redacted health, and resumable shadow rebuild activation.
- Added complete persisted Item-root projection into stable Item and Statement
  document slots with canonical references, CNF visibility/filter rows, traced
  chunks, removal semantics, and identical native SQLite/Workerd D1 lifecycle
  tests. Deferred producers remain explicitly blocked, and no public
  query/ranking/snippet/cursor surface or complete-Site assembly is added.
- Added DDL-only migration 0005 with an immutable, metadata-only unified-search
  source-event log and current registry, plus opaque domain-bound atomic event
  guards and one root event per Taproot Item mutation. The authorization outbox
  is unchanged.
- Added persisted Node SQLite and real Workerd D1 migration/concurrency/
  rollback/security coverage and a reproducible capped 100k ingest artifact.

- Added the additive unified-search V1 type/normalization contract and pure,
  authorization-preserving Statement and Item projection planning. The seven
  kind vocabulary is recognized, while five deferred projectors fail explicitly.
- Added deterministic canonical bytes, hashes, IDs, lossless bounded chunking,
  and cursor-binding inputs. This does not add search execution, persistence,
  migration 0005, ranking, snippets, cursor issuance, health/rebuild, or Site
  deployment, and it does not change legacy term search or SPARQL.

## 0.3.0

- **Breaking 0.3 API:** removed `TaprootRepository`, `createTaproot`, and every
  unscoped canonical read helper from the normal package export. Canonical
  entity, history, list, term-search, audit, export, integrity, and repair
  access now exists only through mandatory `AuthorizedTaprootReader` context.
- Added host-issued non-extractable AES-GCM cursor capability, authenticated
  cursors bound to caller/grants/query/filter/auth revision/data generation,
  fixed-size plaintext padding, identifier-only candidate scans, denied-heavy
  page filling, and final authorization rechecks. Revision and audit generation
  invalidate cursors after writes and repair. Stale, tampered, and cross-context
  cursors fail generically.
- Public mutation helpers now return minimal receipts and reject validator/RDF
  factory callbacks and configurable entity-size probes, so write configuration
  cannot observe preexisting canonical content. They require a process-local
  opaque installation authorization guard bound to the exact database object
  and installation base IRI. Normal writes require current `knowledge:write`;
  policy changes require orthogonal `knowledge:policy`. Raw repository
  internals are not package-exported.
- Added host-created authorization contexts, canonical CNF visibility scopes,
  lossless scope intersection, portable fingerprints, explicit `search:admin`
  checks, and fail-closed pre/post-hydration canonical reads.
- Added checksummed migration 4 with immutable installation authorization
  state, current and per-revision entity/statement policy, atomic projection
  outbox and counter advances, fail-closed legacy quarantine, and bounded
  hash-attested `search:admin` backfill. Unique durable advance IDs prevent
  same-target ABA races for canonical and cross-package ordered batches.
- Runtime JavaScript writes now fail closed when authorization metadata is
  omitted, authorize before loading existing canonical state, validate redirect
  targets and historical reverts against current policy, and preserve generic
  denial behavior for missing, stale, or inaccessible targets.
- Cross-package authorization fencing is guard-executed and inseparable from
  the ordered database batch. Authorization singleton/audit rows reject
  replacement, readiness verifies current and historical statement-policy
  coverage, and authorized bulk import advances its context between entities.
- Added host-issued fence-only domain guards bound to one exact non-Knowledge
  capability. Task/Memory-style writes can share the installation revision
  without borrowing Knowledge authority or advancing counters; Knowledge
  advances require orthogonal policy authority and bind the prior durable
  advance ID.
- Authorization readiness and persisted sources now require exact parity
  between mutable current policy and its immutable matching revision, and
  recompute historical statement coverage/effective visibility before use.
  Operational inspection also validates exact trigger definitions.

- Added required, explicitly authored nonblank `Statement.text` to canonical
  JSON and to every logical statement mutation.
- Added canonical JSON migration 3. Existing databases with no unauthored
  statements upgrade atomically; persisted statements without text fail closed
  rather than receiving inferred fallback prose.
- Whole-entity replacement and historical revert now require an exact
  statement-ID-to-text resupply map, preventing silent stale-text carry.

## 0.2.0

- Added a runtime-neutral SQLite persistence surface while retaining D1
  compatibility types and injection.
- Added checksummed Taproot migration plan, inspect, conservative adoption,
  and apply APIs.
- Made the canonical HTTP(S) base IRI a durable, immutable database identity.
- Added Workerd D1 and process-local Node SQLite parity coverage for reopen,
  rollback, and concurrent writers.

## 0.1.0

- Complete Wikibase Item/Property JSON model and validated editing API.
- Atomic current entities, immutable revisions, terms, RDF, and ownership.
- Structured attribution, tags, request correlation, audit events, and
  SHA-256 parent chains.
- Lifecycle history, redirect resolution/cycle prevention, cursor reads,
  multi-command edits, bounded bulk import/upsert, and NDJSON export.
- Schema/RDF migration, integrity inspection, audit verification, and repair.
- Wikibase-compatible truthy/full RDF mapping version 2 and shared-value safety.
- Host validators, attribution enforcement, observations, deterministic test
  injection, Workerd/D1 tests, Node 22/24 CI, and pack validation.
